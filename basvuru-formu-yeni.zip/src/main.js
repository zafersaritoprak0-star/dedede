
document.getElementById('app').innerHTML = `
<h1>Başvuru Formu</h1>
<form>
<p><input placeholder="Ad Soyad" style="width:300px;padding:8px"></p>
<p><input placeholder="E-posta" style="width:300px;padding:8px"></p>
<p><input placeholder="Telefon" style="width:300px;padding:8px"></p>
<p><textarea placeholder="Mesajınız" style="width:300px;height:120px;padding:8px"></textarea></p>
<p><button type="submit">Gönder</button></p>
</form>`;
